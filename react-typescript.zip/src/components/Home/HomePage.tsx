import { FC } from 'react';

const HomePage: FC = () => {

  return (
    <div className="text-center">
      <h3 className="text-4xl font-bold my-2">Pokemon Listing page</h3>
    </div>
  );
};

export default HomePage;
