// Declare png module
declare module '*.png'

// Declare svg module
declare module '*.svg'
